Version : 17.0.0.1 | Date : 12/6/24
=> Change Analytic Distribution format in Journal Entry Report.
